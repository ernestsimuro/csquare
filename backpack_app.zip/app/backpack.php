<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class backpack extends Model
{
    protected $fillable = [
        'bp_item'
    ];
    //
}
